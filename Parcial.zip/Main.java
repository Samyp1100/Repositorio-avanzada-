
public class Main {
    public static void main(String[] args) {
        Pasajero pasajero1 = new Pasajero("Ana","Arboleda","2","5",19);
        Pasajero pasajero2 = new Pasajero("juliana","duque","2","5",18);
        Pasajero.MenorEdad(pasajero1,pasajero2);
    }
}