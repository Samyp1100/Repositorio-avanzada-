public class Pasajero {
    private String nombre;
    private String apellidos;
    private String NumPasaporte;
    private String Asiento;
    private int edad;

    public Pasajero() {
        this.nombre = "";
        this.apellidos = "";
        NumPasaporte = "";
        Asiento = "";
        this.edad = Integer.parseInt("");
    }

    public Pasajero(String nombre, String apellidos, String numPasaporte, String asiento, int edad) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        NumPasaporte = numPasaporte;
        Asiento = asiento;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNumPasaporte() {
        return NumPasaporte;
    }

    public void setNumPasaporte(String numPasaporte) {
        NumPasaporte = numPasaporte;
    }

    public String getAsiento() {
        return Asiento;
    }

    public void setAsiento(String asiento) {
        Asiento = asiento;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public static void MenorEdad(Pasajero pasajero1, Pasajero pasajero2) {
        if (pasajero1.getEdad() > pasajero2.getEdad()) {
            System.out.println("Pasajero 2 es menor");
        } else if (pasajero2.getEdad() > pasajero1.getEdad()) {
            System.out.println("Pasajero 1 es menor");
        } else {
            System.out.println("las edades son iguales");
        }
    }
}