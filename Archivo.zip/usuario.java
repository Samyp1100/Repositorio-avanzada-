abstract class Usuario {
    protected String nombre;

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    public abstract String getTipo();
}

// Subclase Estudiante de Usuario
class Estudiante extends Usuario {
    public Estudiante(String nombre) {
        super(nombre);
    }

    @Override
    public String getTipo() {
        return "Estudiante";
    }
}

// Subclase Profesor de Usuario
class Profesor extends Usuario {
    public Profesor(String nombre) {
        super(nombre);
    }

    @Override
    public String getTipo() {
        return "Profesor";
    }
}

