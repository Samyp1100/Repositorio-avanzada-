import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
class Biblioteca {
    public Libro[] libro;
    public Usuario[] usuario;
    private List<Libro> libros;
    private List<Prestamo> prestamos;
    private List<Usuario> usuarios;

    public Biblioteca() {
        libros = new ArrayList<>();
        prestamos = new ArrayList<>();
        usuarios = new ArrayList<>();
    }

    // Métodos para agregar libros, usuarios y préstamos
    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    public void prestarLibro(Libro libro, Usuario usuario) {
        if (libros.contains(libro) && usuarios.contains(usuario)) {
            prestamos.add(new Prestamo(libro, usuario));
            libros.remove(libro);
            System.out.println("El libro '" + libro.getTitulo() + "' ha sido prestado a " + usuario.nombre);
        } else {
            System.out.println("El libro o usuario no están registrados en la biblioteca.");
        }
    }

    public void mostrarLibrosDisponibles() {
        System.out.println("Libros disponibles en la biblioteca:");
        for (Libro libro : libros) {
            System.out.println("- " + libro.getTitulo() + " de " + libro.getAutor() + " (" + libro.getAñoPublicacion() + ")");
        }
    }
}