import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Biblioteca biblioteca = new Biblioteca();

        // Agregar algunos libros y usuarios
        biblioteca.agregarLibro(new Libro("El principito", "Antoine de Saint-Exupéry", 1943));
        biblioteca.agregarLibro(new Libro("Cien años de soledad", "Gabriel García Márquez", 1967));
        biblioteca.agregarUsuario(new Estudiante("Juan"));
        biblioteca.agregarUsuario(new Profesor("María"));

        // Interfaz de usuario por consola
        while (true) {
            System.out.println("\nBienvenido a la biblioteca. ¿Qué desea hacer?");
            System.out.println("1. Prestar libro");
            System.out.println("2. Mostrar libros disponibles");
            System.out.println("3. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine();  // Consumir el salto de línea

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el título del libro que desea prestar:");
                    String titulo = scanner.nextLine();
                    System.out.println("Ingrese su nombre:");
                    String nombreUsuario = scanner.nextLine();

                    Libro libro = null;
                    Usuario usuario = null;

                    for (Libro l : biblioteca.libro) {
                        if (l.getTitulo().equalsIgnoreCase(titulo)) {
                            libro = l;
                            break;
                        }
                    }

                    for (Usuario u : biblioteca.usuario) {
                        if (u.nombre.equalsIgnoreCase(nombreUsuario)) {
                            usuario = u;
                            break;
                        }
                    }

                    if (libro != null && usuario != null) {
                        biblioteca.prestarLibro(libro, usuario);
                    } else {
                        System.out.println("El libro o el usuario no están registrados en la biblioteca.");
                    }
                    break;
                case 2:
                    biblioteca.mostrarLibrosDisponibles();
                    break;
                case 3:
                    System.out.println("Gracias por utilizar la biblioteca. ¡Hasta luego!");
                    System.exit(0);
                default:
                    System.out.println("Opción inválida. Por favor, ingrese un número válido.");
            }
        }
    }
}
