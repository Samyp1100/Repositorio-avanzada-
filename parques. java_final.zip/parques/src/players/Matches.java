package players;

import utils.Utils;

import java.io.Serializable;
import java.util.LinkedList;

public class Matches implements Serializable {

    LinkedList<Match> matches;

    public Matches() {
        this.matches = new LinkedList();
    }

    public void saveMatch(Match match) {
        matches.add(match);
        Utils.writeFile(this);
    }

    public LinkedList<Match> getMatches() {
        return matches;
    }

    public LinkedList<Match> filterByNumOfPlayers(int numberOfPlayers){
        LinkedList<Match> matchesFiltered = new LinkedList();
        for (Match m: matches){
            if(m.getLosers().size() + 1 == numberOfPlayers){
                matchesFiltered.add(m);
            }
        }
        return matchesFiltered;
    }
}
