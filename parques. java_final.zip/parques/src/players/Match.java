package players;

import java.io.Serializable;
import java.util.LinkedList;

public class Match implements Serializable {

    Winner winner;
    LinkedList<Loser> losers;

    public Match() {
        losers = new LinkedList();
    }

    public void saveFinalist(Finalist f) {
        if (f instanceof Winner){
            winner = (Winner) f;
        }else {
            losers.add((Loser) f);
        }
        if (winner!= null){
            winner.setOpponents(losers.size());
        }
    }

    public Winner getWinner() {
        return winner;
    }

    public LinkedList<Loser> getLosers() {
        return losers;
    }
}
