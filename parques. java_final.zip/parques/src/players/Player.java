package players;

import java.io.Serializable;

public class Player implements Serializable {

    private String name;
    private int counterTimes = 0;
    private int x;

    public Player() {
        this.trajectoryMatrix = new int[36][2];
    }

    private int y;
    private int xFinal;
    private int yFinal;
    private int xInit;
    private int yInit;

    private int time;
    
    private int positionsCounter;
    
    private final int[][] trajectoryMatrix;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCounterTimes() {
        return counterTimes;
    }

    public void setCounterTimes(int counterTimes) {
        this.counterTimes = counterTimes;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getxFinal() {
        return xFinal;
    }

    public void setxFinal(int xFinal) {
        this.xFinal = xFinal;
    }

    public int getYFinal() {
        return yFinal;
    }

    public void setYFinal(int yFinal) {
        this.yFinal = yFinal;
    }

    public int getxInit() {
        return xInit;
    }

    public void setxInit(int xInit) {
        this.xInit = xInit;
    }

    public int getyInit() {
        return yInit;
    }

    public void setyInit(int yInit) {
        this.yInit = yInit;
    }

    public int getTime() {
        return time;
    }

    public int getyFinal() {
        return yFinal;
    }

    public void setInitialPosition(int time){
        this.time = time;
        switch (time){
            case 0:
                this.xInit = 10;
                this.yInit = 8;
                this.x = 10;
                this.y = 8;
                this.xFinal = 5;
                this.yFinal = 4;
                break;
            case 1:
                this.xInit = 10;
                this.yInit = 0;
                this.x = 10;
                this.y = 0;
                this.xFinal = 7;
                this.yFinal = 4;
                break;
            case 2:
                this.xInit = 0;
                this.yInit = 0;
                this.x = 0;
                this.y = 0;
                this.xFinal = 5;
                this.yFinal = 4;
                break;
            case 3:
                this.xInit = 0;
                this.yInit = 8;
                this.x = 0;
                this.y = 8;
                this.xFinal = 3;
                this.yFinal = 4;
                break;
        }
        buildTrajectoryMatrix(time);
    }

    private void buildTrajectoryMatrix(int time){
        positionsCounter = 0;
        //calcula basada en el turno del jugador
        switch (time) {
            case 0:
                //aca calcula la trayectoria para el jugador cero y en la manera en
                //la que se mueve dentro del tablero
                for (int y = 8; y >= 0; y--) {
                    trajectoryMatrix[positionsCounter][0] = 10;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }

                for (int x = 9; x >= 0; x--) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 0;
                    positionsCounter++;
                }
                for (int y = 1; y <= 8; y++) {
                    trajectoryMatrix[positionsCounter][0] = 0;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }
                for (int x = 1; x <= 5; x++) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 8;
                    positionsCounter++;
                }
                for (int y = 7; y >= 4; y--) {
                    trajectoryMatrix[positionsCounter][0] = 5;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }
                break;
            //este case para lo mismo pero para el jugador numero uno
            case 1:
                for (int x = 10; x >= 0; x--) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 0;
                    positionsCounter++;
                }
                for (int y = 1; y <= 8; y++) {
                    trajectoryMatrix[positionsCounter][0] = 0;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }
                for (int x = 1; x <= 10; x++) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 8;
                    positionsCounter++;
                }
                for (int y = 7; y >= 4; y--) {
                    trajectoryMatrix[positionsCounter][0] = 10;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }
                for (int x = 9; x >= 7; x--) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 4;
                    positionsCounter++;
                }
                break;
            //este caso es para el jugador numero dos
            case 2:
                for (int y = 0; y <= 8; y++) {
                    trajectoryMatrix[positionsCounter][0] = 0;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }
                for (int x = 1; x <= 10; x++) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 8;
                    positionsCounter++;
                }
                for (int y = 7; y >= 0; y--) {
                    trajectoryMatrix[positionsCounter][0] = 10;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }
                for (int x = 9; x >= 5; x--) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 0;
                    positionsCounter++;
                }
                for (int y = 1; y <= 4; y++) {
                    trajectoryMatrix[positionsCounter][0] = 5;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }

                break;
            //este caso calcula la trayectoria y como se mueve para el jugador tres
            case 3:
                for (int x = 0; x <= 10; x++) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 8;
                    positionsCounter++;
                }
                for (int y = 7; y >= 0; y--) {
                    trajectoryMatrix[positionsCounter][0] = 10;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }
                for (int x = 9; x >= 0; x--) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 0;
                    positionsCounter++;
                }
                for (int y = 1; y <= 4; y++) {
                    trajectoryMatrix[positionsCounter][0] = 0;
                    trajectoryMatrix[positionsCounter][1] = y;
                    positionsCounter++;
                }
                for (int x = 1; x <= 3; x++) {
                    trajectoryMatrix[positionsCounter][0] = x;
                    trajectoryMatrix[positionsCounter][1] = 4;
                    positionsCounter++;
                }

                break;
            }
    }

    public int calculateTrajectory() {
        //llamamos a la funcion armar la matriz de trayectoria para construirla
        //este for sirve para recorrer la trayectoria de la matriz
        for (int i = 0; i < positionsCounter; i++) {
            //este if nos ayuda para saber si las cordenadas de la pocision actual coinciden con las del jugador
            if (trajectoryMatrix[i][0] == x && trajectoryMatrix[i][1] == y) {
                return positionsCounter - i;
            }
        }
        return -1;
    }

    public void move(int diceMove){
        int trajectory = calculateTrajectory();
        this.x = trajectoryMatrix[36 - trajectory + diceMove][0];
        this.y = trajectoryMatrix[36 - trajectory + diceMove][1];
    }
}
