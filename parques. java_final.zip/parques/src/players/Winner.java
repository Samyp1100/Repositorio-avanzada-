package players;

import java.util.LinkedList;

public class Winner extends Finalist{
    int opponents;

    public Winner() {
        this.opponents = 0;
    }

    public int getOpponents() {
        return opponents;
    }

    public void setOpponents(int opponents) {
        this.opponents = opponents;
    }
}
