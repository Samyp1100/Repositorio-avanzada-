package players;

import java.io.Serializable;

public class Finalist implements Serializable {


    private String name;
    private int times;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTimes() {
        return times;
    }

    public void setTimes(int times) {
        this.times = times;
    }

}
