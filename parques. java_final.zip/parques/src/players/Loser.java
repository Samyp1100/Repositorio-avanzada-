package players;

public class Loser extends Finalist{
}
