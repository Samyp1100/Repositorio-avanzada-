package utils;

import players.Matches;
import players.Player;

import java.io.*;
import java.util.Collections;
import java.util.LinkedList;

import static java.lang.System.exit;

public class Utils {
    static final int DICE_MIN_VALUE = 1;
    static final int DICE_MAX_VALUE = 6;

    /**
     * Function that simulates a dice behavior
     *
     * @return a random value between DICE_MIN_VALUE and DICE_MAX_VALUE
     */
    public static int dice(){
        return (int)(Math.random() * (DICE_MAX_VALUE - DICE_MIN_VALUE + 1)) + DICE_MIN_VALUE;
    }

    public static void reorderPlayers(LinkedList<Integer> turns) {
        Collections.shuffle(turns);
    }

    public static void showTurns(LinkedList<Integer> turns) {
        for (Integer turn: turns){
            System.out.print(turn+" ");
        }
        System.out.println("\n");
    }

    /**
     *
     * @param m
     * @return
     */
    public static boolean writeFile(Matches m){
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream("matches.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(m);
            oos.close();
            fos.close();
        }
        catch (IOException e) {
            System.err.println("Error inesperado al guardar el archivo: "+e.getMessage());
            return false;
        }
        return true;
    }

    /**
     *
     * @return
     */
    public static Matches leerArchivo(){
        Matches m = null;
        File binaryFile = new File("matches.bin");
        if(binaryFile.exists()){
            try {
                FileInputStream fis = new FileInputStream ("matches.bin");
                ObjectInputStream ois = new ObjectInputStream(fis);
                m = (Matches) ois.readObject ();
                ois.close ();
                fis.close ();
            } catch (Exception ex) {
                System.err.println("Archivo existente con error.");
            }
        }
        if (m == null){
            m=new Matches();
        }
        return m;
    }
}
