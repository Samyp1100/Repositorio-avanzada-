package main;

import java.util.Scanner;

public class Menu {
    private final Game game;
    private final Ranking ranking;
    private final Scanner scanner;

    public Menu(Game game, Ranking ranking, Scanner scanner) {
        this.game = game;
        this.ranking = ranking;
        this.scanner = scanner;
    }

    public void showMenu(){
        while(true){
            int opc = 0;

            System.out.println("Menu principal. Digite la opcion que desea");
            System.out.println("1. Iniciar nueva partida");
            System.out.println("2. Mostrar el ranking de la partida");
            System.out.println("3. Salir del juego");
            System.out.print("Decida: ");

            opc = scanner.nextInt();
            System.out.println("Opcion elegida: " + opc);

            switch (opc){
                case 1:
                    game.startGame();
                    break;
                case 2:
                    ranking.showRanking();
                    break;
                case 3:
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Opcion invalida, intente de nuevo ");
            }
        }
    }
}
