package main;

import exceptions.NotValidMoveException;
import exceptions.NotValidPlayerNumberException;
import players.*;
import utils.Utils;
import java.util.LinkedList;
import java.util.Scanner;

public class Game {
    private final Scanner scanner;
    final int MIN_PLAYERS=2;
    final int MAX_PLAYERS=4;
    
    final int MAX_ROWS_IN_BOARD = 11;
    final int MAX_COLUMNS_IN_BOARD = 9;

    private final LinkedList<Player> players;
    private final LinkedList<Integer> times;
    private final Matches matches;

    public Game(Scanner scanner, Matches matches) {
        this.scanner = scanner;
        this.players = new LinkedList();
        this.times = new LinkedList();
        this.matches = matches;
    }

    /**
     *
     */
    public void startGame(){
        int quantityPlayers =numberOfPlayers();
        players.clear();
        times.clear();
        createPlayers(quantityPlayers);
        Utils.reorderPlayers(times);
        setInitialPositions();
        showBoard(quantityPlayers);
        beginGame(quantityPlayers);
    }

    /**
     *
     * @param quantityPlayers
     */
    private void beginGame(int quantityPlayers) {
        boolean alreadyWin = false;
        Player playerInAttempt;
        while (!alreadyWin){
            for (Integer time: times) { // Dependiendo del arreglo time, necesitamos el jugador en ese turno.
                playerInAttempt = players.get(time);
                System.out.println("Es turno del jugador " + playerInAttempt.getName());
                changeTime(playerInAttempt);
                showBoard(quantityPlayers);
                // Se verifica si el jugador actual ha alcanzado su posición final
                if (playerInAttempt.getX() == playerInAttempt.getxFinal() && playerInAttempt.getY() == playerInAttempt.getyFinal()) {
                    System.out.println("El jugador " + playerInAttempt.getName()+ " es el ganador");
                    alreadyWin= true;
                    saveWinner(playerInAttempt);
                    break;
                }
            }
        }
    }

    /**
     * Guarda el ganador en el objeto Matches
     * @param winner ganador
     */
    private void saveWinner(Player winner) {
        Match match = new Match();
        for (Player p : players){
            Finalist f;
            if (p.equals(winner)){
                f = new Winner();
            }else {
                f = new Loser();
            }
            f.setName(p.getName());
            f.setTimes(p.getCounterTimes());
            match.saveFinalist(f);
        }
        matches.saveMatch(match);
    }

    /**
     * Método que permite cambiar el turno del jugador
     * @param player jugador que está en turno
     */
    void changeTime(Player player) {
        int opc = 0;
        while (opc != 1) {
            System.out.println("Digite el número 1 para ejecutar su turno: ");
            opc = scanner.nextInt();
        }
        int diceValue = Utils.dice();
        System.out.println("El jugador " + player.getName()+ " sacó " +diceValue);
        try {
            if (diceValue < player.calculateTrajectory()) {
                player.move(diceValue);
                playerWasCaptured(player);
            } else {
                throw new NotValidMoveException("No es una jugada válida, salta turno");
            }
        } catch (NotValidMoveException e) {
            System.out.println(e.getMessage());
        } finally {
            player.setCounterTimes(player.getCounterTimes()+1);
        }
    }

    /**
     * Indica si un jugador captura otro
     * @param playerInAttempt
     */
    void playerWasCaptured(Player playerInAttempt) {
        for (Player player: players) {
            if (!playerInAttempt.equals(player)) {
                // este if nos ayuda para saber a que jugador capturaron
                if (player.getX() == playerInAttempt.getX() && player.getY() == playerInAttempt.getY()) {
                    player.setX(player.getxInit());
                    player.setY(player.getyInit());
                    System.out.println("El jugador " +playerInAttempt.getName() + " capturo la pieza de "+ player.getName());
                    //Caso borde: un jugador que está en mi casilla de salida debe ser capturado
                    //Cuando me capturan para evitar problemas de impresión en la pantalla

                    playerInStartPlaceWasCaptured(player);

                    return;
                }
            }
        }
    }

    /**
     * Método para capturar la pieza de alguien que está en la casilla de salida
     * de un jugador que fue previamente capturado.
     * @param capturedPlayer
     */
    private void playerInStartPlaceWasCaptured(Player capturedPlayer) {
        for (Player player: players) {
            if (!capturedPlayer.equals(player)) {
                if (player.getX() == capturedPlayer.getX() && player.getY() == capturedPlayer.getY()) {
                    player.setX(player.getxInit());
                    player.setY(player.getyInit());
                    System.out.println("El jugador " +capturedPlayer.getName() + " capturó la pieza de "+ player.getName());

                    return;
                }
            }
        }

    }

    /**
     * Muestra el tablero con el estado actual del juego
     * @param quantityPlayers
     */
    private void showBoard(int quantityPlayers) {
        //estos for nos ayuda que lo que vaya adentro de estos dos sirvan para los cordenadas x,y
        for (int y = 0; y < MAX_COLUMNS_IN_BOARD; y++) {
            for (int x = 0; x < MAX_ROWS_IN_BOARD; x++) {
                boolean flagPlayer = false;
                //aca verificamos si hay un jugador en la pocision x,y y mostar el numero de jugadro en el tablero 
                for (Integer time: times) {
                    if (players.get(time).getX() == x && players.get(time).getY() == y) {
                        System.out.print("|" + ( time + 1) + "1|");
                        flagPlayer = true;
                    }
                }
                if(flagPlayer){
                    continue;
                }

                if (x == 5 && y == 8) {
                    System.out.print("|10|");
                } else if (x == 10 && y == 4) {
                    System.out.print("|20|");
                } else if (x == 5 && y == 0 && quantityPlayers >= 3) {
                    System.out.print("|30|");
                } else if (x == 0 && y == 4 && quantityPlayers == 4) {
                    System.out.print("|40|");
                } else if (x == 5 && y > 4) {
                    System.out.print("|1 |");
                } else if (y == 4 && x > 7) {
                    System.out.print("|2 |");
                } else if (x == 5 && y > 0 && y < 4 && quantityPlayers >= 3) {
                    System.out.print("|3 |");
                } else if (y == 4 && x > 0 && x < 3 && quantityPlayers == 4) {
                    System.out.print("|4 |");
                } else if (x == 0 || x == 10 || y == 0 || y == 8) {
                    System.out.print("|0 |");
                } else {
                    System.out.print("|  |");
                }
                
            }
            System.out.println();
        }
    }

    /**
     *
     */
    private void setInitialPositions() {
        for (Integer time: times) {
            players.get(time).setInitialPosition(time);
        }
    }

    /**
     *
     * @param quantityPlayers
     */
    private void createPlayers(int quantityPlayers) {
        Player player;
        scanner.nextLine();
        for (int i = 0; i < quantityPlayers; i++) {
            System.out.print("Digite el nombre del jugador " + (i+1) + ": ");
            player=new Player();
            String name = scanner.nextLine();
            player.setName(name);
            players.add(player);
            times.add(i);
        }
    }

    /**
     *
     * @return
     */
    private int numberOfPlayers(){
        int quantityPlayers = 0;
        while(true) {
            try {
                System.out.print("Digite la cantidad de jugadores que estarán en la partida: ");
                quantityPlayers = scanner.nextInt();
                if (quantityPlayers < MIN_PLAYERS || quantityPlayers > MAX_PLAYERS) {
                    throw new NotValidPlayerNumberException("Error: la cantidad de jugadores debe ser entre 2 y 4");
                }
                return quantityPlayers;
            } catch(NotValidPlayerNumberException e){
                System.err.println(e.getMessage());
            }
        }
    }


}
