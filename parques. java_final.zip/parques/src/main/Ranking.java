package main;

import players.Finalist;
import players.Match;
import players.Matches;

import java.util.LinkedList;

public class Ranking {

    private Matches matches;
    public Ranking(Matches matches) {
        this.matches = matches;
    }

    public void showRanking(){
        showWinners();
        for (int i = 2; i < 5; i++) {
            playersSummary(i);
        }
    }

    public void showWinners(){
        System.out.println("Ganadores");
        if (matches.getMatches().isEmpty()){
            System.out.println("No hay ganadores registrados");
        }
        for (Match m: matches.getMatches()){
            Finalist f = m.getWinner();
            System.out.println("Ganador: "+f.getName()+", turnos: "+f.getTimes());
        }
    }

    public void playersSummary(int numberOfPlayers){
        System.out.println("============================================");
        System.out.println("Ganadores con "+numberOfPlayers+" jugadores");
        LinkedList<Match> filtered = matches.filterByNumOfPlayers(numberOfPlayers);
        if (filtered.isEmpty()){
            System.out.println("No hay ganadores registrados");
        }
        for (Match m: filtered){
            Finalist f = m.getWinner();
            System.out.println(f.getName());
        }
    }
}
