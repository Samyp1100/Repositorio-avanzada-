package main;

import players.Matches;
import utils.Utils;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Matches matches = Utils.leerArchivo();
        Game game = new Game(scanner, matches);
        Ranking ranking = new Ranking(matches);
        Menu menu = new Menu(game, ranking, scanner);
        menu.showMenu();
    }
}