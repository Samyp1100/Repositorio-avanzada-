package exceptions;

public class NotValidPlayerNumberException extends Exception{
    public NotValidPlayerNumberException(String s) {
        super(s);
    }
}
